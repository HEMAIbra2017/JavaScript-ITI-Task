
var wind;

function openwindo()
{
wind=open("childwindow.html" ," ", "width=200 , height=150" )
setInterval(function () {moveBy()},50);

}
function closewindo()
{
    wind.close();

}
function moveBy()
{
    wind.moveBy(10,10);
}
