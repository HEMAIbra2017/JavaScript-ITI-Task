var ele = document.getElementById("PAR") ;


function ChangeFont(i)
 {
     ele.style.fontFamily=i;

}

function ChangeAlign(i)
{
    ele.style.textAlign=i;
}

function ChangeHeight(i)
 {
    ele.style.lineHeight=i;
}

function ChangeLSpace(i)
 {
    ele.style.letterSpacing=i;
}

function ChangeIndent(i)
 {
    ele.style.textIndent=i;
}

function ChangeTransform(i)
{
    ele.style.textTransform=i;

}

function ChangeDecorate(i)
 {
    ele.style.textDecoration=i;

 }
function ChangeBorder(i)
{
    ele.style.borderStyle=i;
}

function ChangeBorderColor(i)
{
    ele.style.borderColor=i;
}
