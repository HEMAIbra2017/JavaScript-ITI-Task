var i=1;
var time ;

function nextImg()
{
	 if (i<6){

			i++;
		document.images[0].src=""+i+".jpg"
	} else
	{
			i=1;
	 document.images[0].src="1.jpg";

	 }
}

function previousImg()
{
	 if (i>1){
			 --i;
		document.images[0].src=""+(i)+".jpg";
	} else
	{
			i=6;
	 document.images[0].src="6.jpg";

}
}
function showwindo()

{clearTimeout(time);

	if (i<6){

		 i++;
	document.images[0].src=""+i+".jpg"

	}else i=1
	{
	 document.images[0].src=""+i+".jpg"

	 }
	time = setTimeout(showwindo, 2000);
}
function stopwindo()
{
	 clearTimeout(time);
}
