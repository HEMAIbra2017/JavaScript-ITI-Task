# Udacity Neighbourhood Map Project
**This single page application contains a map of various places with markers and extra.  **
## Table of Contents
1. The requirements
2. Code Dependencies
3. starting the app

## The requirements

- display map markers identifying  5 locations that i hace chosen.
- search box to filter options.
- display information about a specific place when get selected


### Code Dependencies
1. Html5
2. Css3
3. JQuery
4. Knockout JS
5. Google Maps


#### starting the app
**to start the application you need to open _index.html_ and then you will see a map and a search box there will be 5 places are marked by deafult you can use the search box to search for a specific place and click on that marker on map to see the information about it **



