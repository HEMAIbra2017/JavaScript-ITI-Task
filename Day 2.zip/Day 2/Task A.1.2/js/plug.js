var wind;

var i = 0;
var txt = "Hello ";

function typeWriter() {

  wind=open("child.html" ," ", "width=300 , height=300" )

  setInterval( function(){
  if (i < txt.length) {
    wind.document.write(txt.charAt(i));
    i++;
    if ( i== txt.length)
    wind.close();
   }} ,150)
}
