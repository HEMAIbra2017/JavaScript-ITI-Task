
function myFunction(){
 const name = document.getElementById('name').value;
 const title = document.getElementById('title').value;

  sessionStorage.setItem("NAME", name);
    sessionStorage.setItem("title", title);

    return;
}
