window.addEventListener('load', () => {

    const name = sessionStorage.getItem('NAME');
    const title = sessionStorage.getItem('title');

    document.getElementById('demo').innerHTML = " <p style= color:white;font-size:70px;> Welcome  </p>" + title +" " + name;

})
