var i=0 ;
var time ;
function move()
{
    if (i < 4 )
    {

      document.images[i+1].src= "marble3.jpg";
       document.images[i].src= "marble1.jpg";
       i++;
    }else
    {
        i=0;
        document.images[4].src= "marble1.jpg";
        document.images[i].src= "marble3.jpg";
       document.images[i+1].src= "marble1.jpg";
    }

 }

    time=setInterval(move, 300);
   function moveagain()
  {
   time= setInterval(move, 300);
   }


    function stop(){
    clearInterval(time);
    }
