

function Param(x,y){

try{

    if(arguments.length!=2){
         throw " You must write two Param";

     }
      else
    return document.writeln(x*y)
}
catch(f){
         alert(" please ,Enter Two Param ");
}}
