

var linkedList={
   arr:[],

   push:function(v){
   return this.arr.push(v);
    },
    pop:function(){
    return this.arr.pop();
     },
    display:function(){
    console.log("the array is : "+this.arr );
     },
   delete:function(value){
    position = this.arr.indexOf(value);
    if(position>=0)
    this.arr.splice(position,1)
    return this.arr;
     },
    insert:function(position,value2){

    position=this.arr.splice(position,0,value2)
    return this.arr;
     }

}
