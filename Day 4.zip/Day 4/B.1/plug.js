

var linkedList={
   arr:[],

// push item
   push:function(v){
   return this.arr.push(v);
    },
    // pop item
    pop:function(){
    return this.arr.pop();
     },
    display:function(){
    console.log("the array is : "+this.arr );
     },
         // delete
   delete:function(value){
    position = this.arr.indexOf(value);
    if(position>=0)
    this.arr.splice(position,1)
    return this.arr;
     },
  // insert
    insert:function(position,value2){

    position=this.arr.splice(position,0,value2)
    return this.arr;
     }

}
