       var visit;
        window.onload = function() {
            if (hasCookie("visit")) {
                visit = parseInt(getCookieTwo("visit"), 10);
                visit += 1;
                setCookie("visit", visit)
                console.log(visit)
            }
             else {
                setCookie("visit", 1)
            }

            var name=document.querySelector("#name").innerHTML =`${getCookieTwo("name")} `;
            var name=document.querySelector("#num").innerHTML =`${getCookieTwo("visit")} `;
        document.querySelector("#name").style.color=getCookieTwo("color");
        document.querySelector("#num").style.color=getCookieTwo("color");

        if (getCookieTwo("gender")=="female"){

            var img= document.getElementById("imge");
                img.src="2 (1).jpg";
            }

        };


function getCookieTwo(key) {
    if (key == undefined) {
        throw "parameter error"
    }
    var cok = document.cookie;

    var allCookie = cok.split(";");
    var all = {};
    for (i in allCookie) {
        all[allCookie[i].split("=")[0].trim()] = allCookie[i].split("=")[1]
    }
    return all[key]
}

function hasCookie(key) {
    if (key == undefined) {
        throw "parameter error"
    }

    var cok = document.cookie;
    var allCookie = cok.split(";");
    var all = {};
    for (i in allCookie) {
        if ((key) == allCookie[i].split("=")[0].trim()) return true;
    }
    return false;
}

function deleteCookie(key) {
    if (key == undefined) {
        throw "parameter error"
    }
    document.cookie = key + "=; expires=Thu, 01 Jan 1975 00:00:00 UTC; path=/;";
}

function setCookie(key, value) {
    if (key == undefined || value == undefined) {
        throw "parameter error"
    }
    
    var dat = new Date();
    dat.setMonth(dat.getMonth() + 3)
    console.log(dat);
    document.cookie = key + "=" + value + ";expires" + dat;
}
