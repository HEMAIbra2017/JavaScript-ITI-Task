
var Array= [];
for (i=0 ;i<5;i++)
{
    Array[i]=parseInt(prompt("Enter Numbers"));
}

document.write("You`ve Entered the Value of: "+ Array+"<br>"+ "<br>");
document.write(" Your values after being sorted ascending "+ Array.sort(function(a,b){ return a-b }) +"<br>"+ "<br>");
document.write("Your values after being sorted descending "+ Array.reverse());
