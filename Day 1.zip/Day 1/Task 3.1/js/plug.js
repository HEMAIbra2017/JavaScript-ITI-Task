
var number1 =Number(prompt("Enter first Number"));
var number2 =Number(prompt("Enter second Number"));
var number3 =Number(prompt("Enter third Number"));

document.getElementById('demo1').innerHTML="Sum ="+(number1+number2+number3);
document.getElementById('demo2').innerHTML="Multiplication ="+(number1*number2*number3);
document.getElementById('demo3').innerHTML="Division ="+(number1/number2/number3);
