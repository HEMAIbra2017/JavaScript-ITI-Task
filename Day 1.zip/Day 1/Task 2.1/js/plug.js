
var text=window.prompt("Enter Text");

document.getElementById('demo').innerHTML="Text-Length : "+text.length;
//document.write(text.length);
