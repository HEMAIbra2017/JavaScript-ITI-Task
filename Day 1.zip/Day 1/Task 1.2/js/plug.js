

var x = Number(prompt("Enter first number"));
var y = Number(prompt("Enter second number"));
document.getElementById("demo").innerHTML="Sum =" + "<br>"+(x + y);
