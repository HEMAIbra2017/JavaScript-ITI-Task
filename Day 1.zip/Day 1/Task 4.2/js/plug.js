
var r=Number(prompt("Enter value here to calculate The square root"));
alert(" The square root Of :"+Math.sqrt(r));
