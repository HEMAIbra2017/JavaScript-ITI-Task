
var msg=window.prompt("enter Text");

var text=" ";
var i=1;
while(i<=6){
  text+="<h"+i+ ">"+  [msg] +"<h"+i+ ">";
  i++
}
document.getElementById("demo").innerHTML = text;
