// Prompt Name
var name=window.prompt("Enter Your Name :");
document.getElementById('h1').innerHTML="Your Name is :"+ name;
// Prompt Age
var age=window.prompt("Enter age");
document.getElementById('h2').innerHTML="Your Age is  : "+age;
// Prompt Mobile
var mobile=window.prompt("Enter your Mobile number ");
document.getElementById('h3').innerHTML="Your Mobile number is :" + mobile;
// Prompt mail
var mail=window.prompt("Enter your E-mail ");
document.getElementById('h4').innerHTML="Your E-mail is :" + mail;
// Date
var d=new Date();
document.getElementById('h5').innerHTML=d;
