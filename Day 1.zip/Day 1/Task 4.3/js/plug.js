
var r=Number(prompt("Enter value here to calculate the cosine of a number:"));
alert(" the cosine of a number:"+ Math.cos(r));
