
var r=Number(prompt("Enter value here to calculate area of circle"));
alert(" The Total area Of :"+Math.PI * r * r );
