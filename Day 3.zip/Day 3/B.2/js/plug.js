
      document.addEventListener("contextmenu",function(c){
        c.preventDefault();
            alert("It`s prevent")
      })
