


      document.addEventListener("contextmenu",function(c)
      {
             c.preventDefault(); 
            alert("this click is prevent")
      })
