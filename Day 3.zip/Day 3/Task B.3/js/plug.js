
function setok() {
    setTimeout(function() {
        alert("You don't Submit ")
    },500)
}

function sub(e){
    var clc=confirm(" Confirm it or Not");
    if (clc==false)
    {
        e.preventDefault();

    }

}
