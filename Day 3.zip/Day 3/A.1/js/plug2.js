
 window.onload = function() {
    if (hasCookie("name") && hasCookie("age") && hasCookie("gender")) {
        window.location = 'index1.html';
    }
};

function action() {

    var Vname = document.querySelector("#name").value;
    var Kname = "name";
    var Vage = document.querySelector("#age").value;
    var Kage = "age";
    var select = document.querySelector("#color");

     var sort = document.getElementsByName('gender');
    for (i = 0; i < sort.length; i++) {
        if (sort[i].checked)
            Vgender = sort[i].value;
    }
    var Kgender = "gender";
    var KColor = "color";
    var VColor = select.options[select.selectedIndex].value;


    setCookie(Kname, Vname);
    setCookie(Kage, Vage);
    setCookie(Kgender, Vgender);
    setCookie(KColor, VColor);
    window.location = 'index1.html';

}


function getCookieTwo(key) {
    if (key == undefined) {
        throw "parameter error"
    }
    var cok = document.cookie;

    var allCookie = cok.split(";");
    var all = {};
    for (i in allCookie) {
        all[allCookie[i].split("=")[0].trim()] = allCookie[i].split("=")[1]
    }
    return all[key]
}

function hasCookie(key) {
    if (key == undefined) {
        throw "parameter error"
    }
    var cok = document.cookie;
    var allCookie = cok.split(";");
    var all = {};
    for (i in allCookie) {
        if ((key) == allCookie[i].split("=")[0].trim()) return true;
    }
    return false;
}

function deleteCookie(key) {
    if (key == undefined) {
        throw "parameter error"
    }
    document.cookie = key + "=; expires=Thu, 01 Jan 1975 00:00:00 UTC; path=/;";
}

function setCookie(key, value) {
    if (key == undefined || value == undefined) {
        throw "parameter error"
    }
    var dat = new Date();
    dat.setMonth(dat.getMonth() + 3)
    console.log(dat);
    document.cookie = key + "=" + value + ";expires" + dat;
}
