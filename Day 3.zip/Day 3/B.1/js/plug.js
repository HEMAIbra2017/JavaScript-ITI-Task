var text=document.getElementById("Txt")

function display(ask){
  var Askk;
    Askk=ask.keyCode;

  if (Askk==17)
  {
    alert("taht's Ctrl")
  }
  else if (Askk==18)
  {
    alert("taht's  Alt")
  }
  else if (Askk==16)
  {
    alert("taht's shift")
  }
  else

     document.getElementById("p1").innerHTML = " <p style=color:red > The aski key code is: </p>" + Askk;
}
